import {books} from '../../app/bookInformation';
export const bookdata: books[]=[
    {bookname:'C programming absolute beginner guide ',author:'Greg Perry and Dean Miller',genre:'EDUCATION',yearpublished:2004,picture:'assets/img/C.jpg'},
    {bookname:'Java: The Complete Reference, Eleventh Edition',author:' Herbert Schildt',genre:'EDUCATION',yearpublished:2018,picture:'assets/img/javaforbeg_.jpg'},
    {bookname:'Java for Dummies',author:'Barry A Burd',genre:'EDUCATION',yearpublished:2014,picture:'assets/img/javaforddum.jpg'},
    {bookname:'Murach Asp.net core',author:'Joel Murach and Mary delameter',genre:'EDUCATION',yearpublished:2016,picture:'assets/img/.net.jpg'}
];